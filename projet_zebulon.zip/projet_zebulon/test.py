a = []
for i in range(5):
    a += [(i, i)]
    print(a)